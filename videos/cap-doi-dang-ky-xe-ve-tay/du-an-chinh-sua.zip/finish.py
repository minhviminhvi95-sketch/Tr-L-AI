from pathlib import Path
import json,subprocess,zipfile,shutil,hashlib
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'renders';DELIVERY=ROOT/'delivery';DELIVERY.mkdir(exist_ok=True)
m=json.loads((ROOT/'manifest.json').read_text())
def f(size,bold=False):return ImageFont.truetype('/usr/share/fonts/truetype/noto/NotoSans-'+('Bold' if bold else 'Regular')+'.ttf',size)
im=Image.new('RGB',(1280,720),'#F5EBD7');d=ImageDraw.Draw(im)
d.text((65,47),'NGUỒN VÀ CÁCH SỬ DỤNG VIDEO',font=f(36,True),fill='#373A3C')
d.text((65,106),'17 phân cảnh • Có giọng đọc, phụ đề và khoảng dừng để theo dõi',font=f(23),fill='#467DAB')
items=[('VIDEO GỐC','IMG_8179.MP4 do bạn cung cấp • 4 phút 25,9 giây'),
('ĐỐI CHIẾU THAO TÁC','Bảng mốc nguồn và video riêng từng bước được gửi kèm.'),
('DỮ LIỆU MINH HỌA','Màn hình vẽ lại; không dùng thông tin tài khoản, mã hoặc hồ sơ thật.'),
('LƯU Ý THỰC HIỆN','Ví dụ thay đổi màu sơn còn yêu cầu đưa xe đến kiểm tra.'),
('NGUỒN THAM KHẢO','Bộ Công an • Cổng dịch vụ công • Đối chiếu ngày 21/10/2026')]
for j,(title,body) in enumerate(items):
 y=181+j*87
 d.text((65,y),title,font=f(18,True),fill='#467DAB')
 d.text((65,y+29),body,font=f(23),fill='#373A3C')
d.line((65,636,1215,636),fill='#C8BDA6',width=1)
d.text((65,656),'Kịch bản, nguồn, phụ đề và bảng cắt: xem các tệp đi kèm.',font=f(23),fill='#373A3C')
im.save(OUT/'credits.png')
subprocess.run(['ffmpeg','-y','-v','error','-loop','1','-framerate','24','-i',str(OUT/'credits.png'),'-f','lavfi','-i','anullsrc=r=48000:cl=mono','-t','12','-c:v','libx264','-preset','fast','-crf','20','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k',str(OUT/'credits.mp4')],check=True)
files=[OUT/f'scene-{i:02}.mp4' for i in range(1,len(m)+1)]+[OUT/'credits.mp4']
assert all(p.is_file() for p in files)
(OUT/'concat.txt').write_text('\n'.join("file '"+str(p)+"'" for p in files)+'\n')
main=DELIVERY/'cap-doi-dang-ky-xe-ve-tay.mp4'
subprocess.run(['ffmpeg','-y','-v','error','-f','concat','-safe','0','-i',str(OUT/'concat.txt'),'-c','copy','-movflags','+faststart','-metadata','title=Cấp đổi chứng nhận đăng ký xe — vẽ tay theo video gốc',str(main)],check=True)
chapters=[';FFMETADATA1']
for s in m:chapters+=['[CHAPTER]','TIMEBASE=1/1000',f'START={round(s["offset"]*1000)}',f'END={round((s["offset"]+s["duration"])*1000)}','title='+s['title']]
(OUT/'chapters.txt').write_text('\n'.join(chapters))
temp=DELIVERY/'chaptered.mp4'
subprocess.run(['ffmpeg','-y','-v','error','-i',str(main),'-i',str(OUT/'chapters.txt'),'-map_metadata','0','-map_chapters','1','-c','copy','-movflags','+faststart',str(temp)],check=True);temp.replace(main)
for name in ['phu-de.srt','bang-cat-theo-buoc.csv','KICH-BAN-VA-NGUON.md']:
 shutil.copy2(ROOT/name,DELIVERY/name)
with zipfile.ZipFile(DELIVERY/'video-tung-buoc.zip','w',zipfile.ZIP_DEFLATED) as z:
 for s in m:
  p=OUT/f'scene-{s["index"]:02}.mp4';z.write(p,p.name)
 z.write(ROOT/'bang-cat-theo-buoc.csv','bang-cat-theo-buoc.csv')
 z.write(ROOT/'KICH-BAN-VA-NGUON.md','KICH-BAN-VA-NGUON.md')
with zipfile.ZipFile(DELIVERY/'giong-doc-tung-buoc.zip','w',zipfile.ZIP_DEFLATED) as z:
 for s in m:
  p=ROOT/'audio'/f'scene-{s["index"]:02}.wav';z.write(p,p.name)
with zipfile.ZipFile(DELIVERY/'du-an-chinh-sua.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ['content.py','make_art.py','prepare.py','render.py','finish.py','manifest.json','hand.png','KICH-BAN-VA-NGUON.md','bang-cat-theo-buoc.csv','phu-de.srt']:
  z.write(ROOT/name,name)
 for p in (ROOT/'art').glob('*'):z.write(p,str(p.relative_to(ROOT)))
subprocess.run(['ffmpeg','-y','-v','error','-ss',str(m[6]['offset']+m[6]['duration']-1),'-i',str(main),'-frames:v','1',str(DELIVERY/'anh-xem-truoc.jpg')],check=True)
sha=hashlib.sha256(main.read_bytes()).hexdigest();(DELIVERY/'SHA256.txt').write_text(sha+'  '+main.name+'\n')
print('FINAL',main,sha,flush=True)
for p in DELIVERY.iterdir():print(p.name,p.stat().st_size,flush=True)
