SOURCE_URL='https://github.com/minhviminhvi95-sketch/Tr-L-AI/releases/download/V1.0.0/IMG_8179.MP4'
SCENES=[
dict(title='CẤP ĐỔI CHỨNG NHẬN ĐĂNG KÝ XE',tag='Dựng theo video gốc • Ví dụ: thay đổi màu sơn',source=[0,23],ui='Truy cập cổng dịch vụ công',fields=['dichvucong.bocongan.gov.vn','Kiểm tra đúng địa chỉ cổng','Chọn Đăng nhập'],button='Đăng nhập',notes=['Mở trình duyệt','Kiểm tra địa chỉ','Chuẩn bị tài khoản VNeID'],sentences=[
'Video này hướng dẫn theo các thao tác trong bản quay màn hình bạn cung cấp: cấp đổi chứng nhận đăng ký xe, với ví dụ thay đổi màu sơn.',
'Đầu tiên, mở trình duyệt và truy cập đúng cổng dịch vụ công. Kiểm tra tên miền trước khi đăng nhập.',
'Các màn hình trong bản vẽ tay đã được dựng lại để dễ đọc. Thông tin cá nhân, mật khẩu và mã xác thực thật không được hiển thị.']),
dict(title='01 / ĐĂNG NHẬP VÀ XÁC THỰC',tag='Chỉ dùng tài khoản của người thực hiện thủ tục',source=[23,71],ui='Đăng nhập VNeID',fields=['Số định danh: [đã che]','Mật khẩu: ••••••••','Mã xác thực: [đã che]'],button='Xác nhận',notes=['Chọn đăng nhập VNeID','Nhập thông tin của bạn','Xác thực theo hướng dẫn'],sentences=[
'Tại trang đăng nhập, chọn phương thức tài khoản định danh điện tử phù hợp, như thao tác đăng nhập qua VNeID trong video.',
'Nhập thông tin tài khoản của chính bạn, rồi thực hiện bước xác thực mà hệ thống yêu cầu. Không dùng các giá trị xuất hiện trong video làm dữ liệu mẫu.',
'Sau khi xác thực thành công, chờ hệ thống đưa trở lại cổng dịch vụ công. Không chia sẻ mật khẩu hoặc mã xác thực cho người khác.']),
dict(title='02 / MỞ MỤC NỘP HỒ SƠ',tag='Menu → Nộp hồ sơ trực tuyến',source=[71,82],ui='Dịch vụ công trực tuyến',fields=['Mở menu của cổng','Nộp hồ sơ trực tuyến','Lĩnh vực đăng ký, quản lý xe'],button='Tìm thủ tục',notes=['Mở menu','Chọn nộp hồ sơ','Đến danh sách thủ tục'],sentences=[
'Sau khi đăng nhập, mở menu điều hướng của cổng dịch vụ công.',
'Chọn mục nộp hồ sơ trực tuyến. Màn hình chuyển sang phần tìm kiếm và lựa chọn thủ tục.',
'Trong video, người thực hiện dùng lĩnh vực đăng ký, quản lý phương tiện để tìm thủ tục về đăng ký xe.']),
dict(title='03 / CHỌN ĐÚNG THỦ TỤC CẤP ĐỔI',tag='Phân biệt cấp đổi với cấp lại hoặc đăng ký lần đầu',source=[82,103],ui='Lựa chọn dịch vụ công',fields=['Cấp đổi chứng nhận đăng ký xe','Chọn cơ quan có thẩm quyền','Kiểm tra nội dung thủ tục'],button='Chọn thủ tục',notes=['Tìm nội dung cấp đổi','Không chọn nhầm cấp lại','Đọc yêu cầu của dịch vụ'],sentences=[
'Tìm mục cấp đổi chứng nhận đăng ký xe theo danh sách dịch vụ đang hiển thị.',
'Phân biệt cấp đổi với cấp lại do bị mất, và với đăng ký xe lần đầu. Chọn đúng nội dung phù hợp hồ sơ của bạn.',
'Tên hoặc vị trí của dịch vụ có thể thay đổi theo thời điểm. Đọc mô tả và yêu cầu hiện hành trước khi tiếp tục.']),
dict(title='04 / CHỌN LOẠI XE VÀ NƠI GIẢI QUYẾT',tag='Chọn theo hồ sơ thực tế, không sao chép địa phương mẫu',source=[103,125],ui='Chọn trường hợp hồ sơ',fields=['Loại xe: Xe máy','Tỉnh / thành phố: theo hồ sơ','Phường / xã: đúng thẩm quyền'],button='Đồng ý và tiếp tục',notes=['Chọn loại xe','Chọn tỉnh và phường/xã','Kiểm tra rồi tiếp tục'],sentences=[
'Ở phần chọn trường hợp hồ sơ, chọn loại xe. Bản quay minh họa lựa chọn xe máy.',
'Tiếp theo, chọn tỉnh, thành phố và phường, xã hoặc cơ quan giải quyết mà dịch vụ yêu cầu. Chọn theo nơi và thẩm quyền phù hợp hồ sơ thực tế.',
'Kiểm tra lựa chọn và thông tin thời hạn đang hiển thị. Sau đó bấm đồng ý và tiếp tục.']),
dict(title='05 / XÁC ĐỊNH NGƯỜI NỘP HỒ SƠ',tag='Chủ xe và người khai hộ là hai vai trò khác nhau',source=[125,134],ui='Người thực hiện thủ tục',fields=['Người nộp hồ sơ là chủ xe','Người nộp là người khai hộ','Chọn đúng vai trò thực tế'],button='Kê khai hồ sơ',notes=['Xác định vai trò','Chủ xe hoặc khai hộ','Không chọn tùy tiện'],sentences=[
'Tại màn hình kê khai, xác định người đang nộp hồ sơ là chủ xe hay người khai hộ.',
'Trong video, ô người nộp hồ sơ là chủ xe được chọn. Bạn chỉ chọn mục này khi đúng với trường hợp của mình.',
'Nếu thực hiện thay người khác, chọn đúng vai trò và chuẩn bị thông tin, giấy tờ theo yêu cầu của dịch vụ.']),
dict(title='06 / CHỌN NỘI DUNG VÀ LÝ DO CẤP ĐỔI',tag='Ví dụ trong video: đổi đăng ký xe do thay đổi màu sơn',source=[134,150],ui='Tra cứu thông tin xe',fields=['Nội dung: Đổi lại đăng ký xe','Lý do: Thay đổi màu sơn','Kiểm tra đúng trường hợp'],button='Tiếp tục kê khai',notes=['Chọn nội dung cần đổi','Chọn lý do chính xác','Ví dụ: thay đổi màu sơn'],sentences=[
'Tại phần tra cứu thông tin xe, chọn nội dung đăng ký cần đổi và lý do tương ứng.',
'Bản quay chọn đổi lại đăng ký xe, với lý do thay đổi màu sơn. Đây là ví dụ cụ thể, không phải lựa chọn chung cho mọi hồ sơ.',
'Nếu nhu cầu của bạn khác, chọn đúng lý do thực tế. Không chọn thay đổi màu sơn chỉ vì video minh họa mục này.']),
dict(title='07 / TRA CỨU THÔNG TIN PHƯƠNG TIỆN',tag='Biển số • Số khung • Số máy • Màu biển • Mã bảo mật',source=[150,185],ui='Tra cứu thông tin xe',fields=['Biển số / số khung: của xe bạn','Số máy / màu biển: đối chiếu','Mã bảo mật: theo màn hình'],button='Tra cứu',notes=['Nhập đúng thông tin xe','Nhập mã bảo mật','Bấm Tra cứu và kiểm tra'],sentences=[
'Nhập biển số, số khung và các trường mà hệ thống yêu cầu. Đối chiếu trực tiếp với chứng nhận đăng ký và giấy tờ hợp lệ của xe.',
'Chọn màu biển phù hợp. Nhập mã bảo mật đang hiển thị trên màn hình, rồi bấm tra cứu.',
'Kiểm tra thông tin trả về và số máy nếu được yêu cầu. Không dùng số khung, số máy hoặc mã bảo mật trong video của người khác.']),
dict(title='08 / KIỂM TRA THÔNG TIN CHỦ XE',tag='Rà soát dữ liệu tự điền và thông tin liên hệ',source=[185,198],ui='Phần chủ xe tự kê khai',fields=['Định danh / họ tên: [đã che]','Số điện thoại / email: [đã che]','Đại diện / ủy quyền: nếu có'],button='Kiểm tra thông tin',notes=['Đối chiếu thông tin chủ xe','Kiểm tra điện thoại, email','Kê khai phần liên quan'],sentences=[
'Cuộn tới phần chủ xe tự kê khai và kiểm tra dữ liệu định danh, giấy tờ, địa chỉ cùng các thông tin liên quan.',
'Kiểm tra số điện thoại và email để nhận được thông báo xử lý hồ sơ.',
'Chỉ kê khai các phần đại diện, ủy quyền hoặc giấy tờ khác khi đúng trường hợp và theo hướng dẫn. Không tự điền dữ liệu không có căn cứ.']),
dict(title='09 / CHỌN CÁCH NHẬN KẾT QUẢ',tag='Chọn theo nhu cầu và phương án dịch vụ hỗ trợ',source=[198,205],ui='Hình thức nhận kết quả',fields=['Đến cơ quan giải quyết nhận','Qua bưu điện tại nhà','Chọn phương án phù hợp'],button='Đồng ý và tiếp tục',notes=['Mở danh sách hình thức','Chọn trực tiếp hoặc bưu chính','Kiểm tra người và nơi nhận'],sentences=[
'Ở trường hình thức nhận kết quả, mở danh sách các phương án mà dịch vụ hỗ trợ.',
'Chọn nhận tại cơ quan giải quyết hoặc qua dịch vụ bưu chính nếu phù hợp. Bản quay có thao tác mở danh sách này để lựa chọn.',
'Nếu nhận qua bưu chính, kiểm tra người nhận, số điện thoại và địa chỉ. Thực hiện các yêu cầu về giấy tờ gốc theo hướng dẫn của cơ quan tiếp nhận.']),
dict(title='10 / BỔ SUNG THÀNH PHẦN HỒ SƠ',tag='Tải đúng giấy tờ, đúng định dạng và đủ nội dung',source=[205,215],ui='Thành phần hồ sơ',fields=['Giấy khai đăng ký xe theo mẫu','Chọn tệp đúng mục yêu cầu','Giấy tờ khác: nếu có'],button='Đồng ý và tiếp tục',notes=['Đọc danh mục giấy tờ','Chọn tệp vào đúng mục','Kiểm tra tệp trước khi đi tiếp'],sentences=[
'Tại màn hình thành phần hồ sơ, đọc danh mục giấy tờ được yêu cầu cho trường hợp của mình.',
'Dùng nút chọn tệp để tải tài liệu vào đúng mục. Bảo đảm bản chụp hoặc bản quét rõ nội dung, đủ trang và đúng định dạng được chấp nhận.',
'Không bỏ qua giấy tờ bắt buộc chỉ vì bản quay cuộn nhanh qua mục này. Kiểm tra các tệp rồi bấm đồng ý và tiếp tục.']),
dict(title='11 / RÀ SOÁT TOÀN BỘ HỒ SƠ',tag='Đọc lại trước khi xác nhận gửi',source=[215,232],ui='Kiểm tra trước khi nộp',fields=['Thông tin xe: đối chiếu lại','Thông tin chủ xe: đúng người','Giấy tờ đính kèm: đủ và đúng'],button='Kiểm tra trước khi nộp',notes=['Rà lại thông tin xe','Rà lại thông tin chủ xe','Rà lại tệp và cách nhận'],sentences=[
'Ở màn hình tổng hợp, đọc lại thông tin phương tiện và chủ xe một lần nữa.',
'Kiểm tra lý do cấp đổi, giấy tờ đính kèm và phương án nhận kết quả. Sửa các điểm sai trước khi gửi hồ sơ.',
'Nếu hệ thống hiển thị thông tin phí, lệ phí, đọc đúng thông báo của hồ sơ mình. Một con số trong bản quay không có nghĩa mọi trường hợp đều được miễn phí.']),
dict(title='12 / KIỂM TRA ĐỊA CHỈ NHẬN',tag='Chỉ áp dụng các trường địa chỉ đúng hình thức đã chọn',source=[232,244],ui='Thông tin nhận kết quả',fields=['Họ tên / số điện thoại người nhận','Tỉnh, thành phố / phường, xã','Số nhà, đường, tổ, ấp, khu phố'],button='Xác nhận nơi nhận',notes=['Kiểm tra người nhận','Kiểm tra địa phương','Kiểm tra địa chỉ chi tiết'],sentences=[
'Nếu hồ sơ yêu cầu khai nơi nhận kết quả, kiểm tra tên và số điện thoại của người nhận.',
'Chọn tỉnh, thành phố, phường, xã và nhập địa chỉ chi tiết theo biểu mẫu.',
'Nếu bạn chọn đến cơ quan nhận trực tiếp, thực hiện theo những trường tương ứng. Không tự sao chép địa chỉ của người quay video.']),
dict(title='13 / NHẬP MÃ VÀ ĐỌC CAM KẾT',tag='Mã xác nhận thay đổi; không dùng mã trong video',source=[244,256],ui='Mã xác nhận và cam kết',fields=['Nhập mã đang hiển thị','Đổi mã nếu khó đọc','Đọc cam kết trước khi tích chọn'],button='Xác nhận cam kết',notes=['Đọc mã trên màn hình','Nhập mã chính xác','Đọc và tích cam kết'],sentences=[
'Nhập mã xác nhận đang xuất hiện trên trang. Mã có thể thay đổi khi tải lại hoặc đổi mã, vì vậy không chép mã trong video.',
'Nếu khó đọc, dùng chức năng đổi mã rồi nhập lại cẩn thận.',
'Đọc nội dung cam kết về tính chính xác của thông tin. Chỉ tích xác nhận sau khi đã rà soát hồ sơ.']),
dict(title='14 / BẤM NỘP HỒ SƠ',tag='Kiểm tra đủ thông tin, mã xác nhận và cam kết',source=[256,259],ui='Xác nhận nộp hồ sơ',fields=['Thông tin và tài liệu đã kiểm tra','Mã xác nhận đã nhập đúng','Cam kết đã đọc và xác nhận'],button='Nộp hồ sơ',notes=['Kiểm tra lần cuối','Bấm Nộp hồ sơ','Chờ phản hồi của hệ thống'],sentences=[
'Sau khi kiểm tra thông tin, mã xác nhận và cam kết, bấm nút nộp hồ sơ.',
'Chờ hệ thống phản hồi. Tránh bấm liên tục hoặc tự gửi lại nhiều lần khi trang đang xử lý.',
'Lưu thông báo và mã hồ sơ khi được cung cấp. Mã này dùng để theo dõi tình trạng giải quyết.']),
dict(title='15 / ĐỌC ĐÚNG KẾT QUẢ CUỐI VIDEO',tag='Lỗi trình duyệt và tin nhắn tiếp nhận là hai thông tin khác nhau',source=[259,265.9],ui='Kiểm tra trạng thái hồ sơ',fields=['Trình duyệt: xuất hiện lỗi trang','Tin nhắn: báo đăng ký thành công','Lưu mã hồ sơ và tra cứu'],button='Tra cứu hồ sơ',notes=['Không chỉ nhìn lỗi trình duyệt','Kiểm tra cả tin nhắn thông báo','Tra cứu mã trước khi nộp lại'],sentences=[
'Ở cuối video gốc, trình duyệt hiển thị lỗi tải trang. Đồng thời, một tin nhắn từ cổng dịch vụ công thông báo đăng ký hồ sơ thành công.',
'Vì vậy, không thể kết luận chỉ từ màn hình lỗi rằng hồ sơ chưa được gửi. Hãy lưu mã trong thông báo và tra cứu trạng thái.',
'Thông báo đăng ký hồ sơ thành công chưa phải là chứng nhận đăng ký xe đã được cấp đổi. Theo dõi yêu cầu bổ sung hoặc liên hệ nơi tiếp nhận trước khi nộp lại.']),
dict(title='SAU KHI NỘP / THEO DÕI VÀ HOÀN TẤT',tag='Ví dụ thay đổi màu sơn: còn yêu cầu kiểm tra thực tế xe',source=None,ui='Theo dõi hướng dẫn giải quyết',fields=['Kiểm tra thông báo bổ sung','Thay đổi màu sơn: kiểm tra xe','Nhận kết quả theo hướng dẫn'],button='Theo dõi hồ sơ',notes=['Theo dõi trạng thái xử lý','Thực hiện yêu cầu kiểm tra xe','Nhận kết quả khi được giải quyết'],sentences=[
'Sau khi gửi, theo dõi trạng thái và thực hiện yêu cầu bổ sung của cơ quan giải quyết nếu có.',
'Với trường hợp đổi chứng nhận đăng ký do thay đổi màu sơn như ví dụ, còn có yêu cầu đưa xe đến cơ quan đăng ký để kiểm tra theo quy định. Nộp trực tuyến không đồng nghĩa đã hoàn tất mọi bước.',
'Nhận kết quả theo hướng dẫn và hình thức đã lựa chọn. Video này minh họa thao tác từ bản quay, không thay thế việc kiểm tra yêu cầu của dịch vụ hiện hành.'])
]
SOURCES=[
('Video gốc do người dùng cung cấp, dài 265,9 giây',SOURCE_URL),
('Bộ Công an: yêu cầu kiểm tra thực tế xe khi đổi đăng ký do thay đổi màu sơn','https://bocongan.gov.vn/bai-viet/quy-dinh-ve-cap-thu-hoi-chung-nhan-dang-ky-xe-bien-so-xe-co-gioi-xe-may-chuyen-dung-d1-t1591'),
('Cổng DVC Bộ Công an: hướng dẫn cấp đổi, ngoại lệ kiểm tra xe cải tạo và thay đổi màu sơn','https://dichvucong.bocongan.gov.vn/public/link-to/chi-tiet-thu-tuc?ma-thu-tuc=64209'),
('Quyết định 4685/QĐ-BCA-C08 ngày 23/7/2026: thủ tục đăng ký xe thống nhất, tránh dùng cứng tên dịch vụ cũ','https://congan.khanhhoa.gov.vn/FileStorage/images/phapche/Q%C4%90%20TTHC/4685-Q%C4%90-BCA.pdf')]
