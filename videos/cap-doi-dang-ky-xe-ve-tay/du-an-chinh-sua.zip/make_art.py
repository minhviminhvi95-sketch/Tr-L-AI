from pathlib import Path
import cairosvg
from PIL import Image,ImageDraw,ImageFont
from content import SCENES
ROOT=Path(__file__).resolve().parent
ART=ROOT/'art';ART.mkdir(exist_ok=True)
PAPER='#F5EBD7';INK='#373A3C';BLUE='#467DAB';ORANGE='#CE9151'
def path(d,color=INK,width=3,fill='none'):
 return f'<path d="{d}" stroke="{color}" stroke-width="{width}" fill="{fill}" stroke-linecap="round" stroke-linejoin="round"/>'
def rect(x,y,w,h,color=INK,r=10,fill='none',width=3):
 return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" stroke="{color}" fill="{fill}" stroke-width="{width}"/>'
for index,s in enumerate(SCENES,1):
 body=rect(65,183,510,385,r=16)+path('M66 226 L574 226',BLUE,2)
 body+=path('M87 204 L94 204 M106 204 L113 204 M125 204 L132 204',BLUE,5)
 for y in (282,359,436):
  body+=rect(88,y,464,53,color=BLUE if y==359 else INK,r=7,width=2)
 body+=rect(307,514,245,37,color=BLUE,r=8,fill='#E0E5DB',width=2)
 for j,y in enumerate((260,390,500)):
  body+=f'<circle cx="660" cy="{y}" r="21" fill="none" stroke="{BLUE}" stroke-width="3"/>'
  line_y=(321,421,551)[j]
  body+=path(f'M697 {line_y} Q927 {line_y+3} 1199 {line_y-1}',ORANGE,2)
 body+=path('M600 359 L620 359 M611 349 L622 359 L611 369',INK,3)
 svg=f'<svg xmlns="http://www.w3.org/2000/svg" width="1280" height="720"><rect width="1280" height="720" fill="{PAPER}"/>{body}</svg>'
 (ART/f'scene-{index:02}.svg').write_text(svg)
 cairosvg.svg2png(bytestring=svg.encode(),write_to=str(ART/f'scene-{index:02}.png'))
print('Prepared',len(SCENES),'screen layouts without any source personal data')
