from pathlib import Path
import json,math,csv
import numpy as np
import sherpa_onnx,soundfile as sf
from content import SCENES,SOURCES,SOURCE_URL
ROOT=Path(__file__).resolve().parent
ART=ROOT/'art';ART.mkdir(exist_ok=True)
AUDIO=ROOT/'audio';AUDIO.mkdir(exist_ok=True)
MODEL=ROOT.parent/'moto-video/models/vits-piper-vi_VN-vais1000-medium'
config=sherpa_onnx.OfflineTtsConfig(model=sherpa_onnx.OfflineTtsModelConfig(vits=sherpa_onnx.OfflineTtsVitsModelConfig(model=str(MODEL/'vi_VN-vais1000-medium.onnx'),tokens=str(MODEL/'tokens.txt'),data_dir=str(MODEL/'espeak-ng-data')),num_threads=2))
tts=sherpa_onnx.OfflineTts(config);sr=22050
def tc(sec):
 ms=round(sec*1000);seconds,ms=divmod(ms,1000);minutes,seconds=divmod(seconds,60);hours,minutes=divmod(minutes,60)
 return f'{hours:02}:{minutes:02}:{seconds:02},{ms:03}'
manifest=[];offset=0;srt=[];cues=0
for index,s in enumerate(SCENES,1):
 parts=[np.zeros(round(.7*sr),dtype=np.float32)];cursor=.7;segments=[]
 for j,text in enumerate(s['sentences']):
  p=AUDIO/f'scene-{index:02}-sentence-{j+1}.wav'
  if p.exists():samples,rate=sf.read(p,dtype='float32')
  else:
   spoken=text.replace('VNeID','vi en ai đi').replace('email','i meo').replace('PDF','pi đi ép').replace('JPG','giây pi gi')
   a=tts.generate(spoken,sid=0,speed=.91);samples=np.asarray(a.samples);rate=a.sample_rate
   samples=samples*min(1,.91/max(float(np.max(np.abs(samples))),1e-5));sf.write(p,samples,rate)
  assert rate==sr
  duration=len(samples)/sr
  segments.append(dict(text=text,start=cursor,end=cursor+duration,duration=duration))
  # Balanced cues, so a trailing word never flashes on its own.
  words=text.split();count=max(1,math.ceil(len(text)/95));groups=[]
  for k in range(count):groups.append(' '.join(words[round(k*len(words)/count):round((k+1)*len(words)/count)]))
  at=cursor;chars=sum(map(len,groups))
  for chunk in groups:
   span=duration*len(chunk)/chars;cues+=1
   srt.append(f'{cues}\n{tc(offset+at)} --> {tc(offset+at+span-.03)}\n{chunk}\n');at+=span
  parts.extend([samples,np.zeros(round(.7*sr),dtype=np.float32)]);cursor+=duration+.7
 exact=math.ceil((cursor+3.8)*24)/24
 parts.append(np.zeros(max(0,round(exact*sr)-sum(map(len,parts))),dtype=np.float32))
 wave=np.concatenate(parts);sf.write(AUDIO/f'scene-{index:02}.wav',wave,sr)
 current={**s,'index':index,'segments':segments,'duration':len(wave)/sr,'offset':offset};manifest.append(current);offset+=current['duration']
 ann={'sceneId':f'scene-{index:02}','canvas':{'width':1280,'height':720},'storyBasis':' '.join(s['sentences']),'sceneDurationMs':round(current['duration']*1000),'elements':[]}
 # Each narration event reveals its relevant part of the form and note outline.
 areas=[{'x':58,'y':176,'width':1160,'height':178},{'x':58,'y':354,'width':1160,'height':76},{'x':58,'y':430,'width':1160,'height':144}]
 for j,(seg,area) in enumerate(zip(segments,areas)):
  ann['elements'].append({'id':f'event-{j+1}','label':s['notes'][j],'sequence':j+1,'narrativeRole':f'Thao tác thứ {j+1} của phân cảnh','subtitle':seg['text'],'type':'interface','region':area,'reveal':{'direction':'top_to_bottom','startMs':round(seg['start']*1000),'durationMs':round(min(6.0,max(2.4,seg['duration']*.6))*1000),'maskPaddingPx':0,'protectedRegions':[]},'handPath':{'start':[90,area['y']+6],'end':[1100,area['y']+area['height']-6],'easing':'easeInOut'}})
 (ART/f'scene-{index:02}.annotation.json').write_text(json.dumps(ann,ensure_ascii=False,indent=2))
 print(f'SCENE {index:02}: {current["duration"]:.2f}s',flush=True)
(ROOT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
(ROOT/'phu-de.srt').write_text('\n'.join(srt))
with (ROOT/'bang-cat-theo-buoc.csv').open('w',newline='',encoding='utf-8-sig') as f:
 writer=csv.writer(f);writer.writerow(['phan_canh','noi_dung','nguon_bat_dau_giay','nguon_ket_thuc_giay','ban_dung_bat_dau_giay','thoi_luong_giay'])
 for s in manifest:writer.writerow([s['index'],s['title'],*(s['source'] or ['','']),round(s['offset'],3),round(s['duration'],3)])
notes=['# Cấp đổi chứng nhận đăng ký xe — dựng theo video gốc','',f'Video nguồn: {SOURCE_URL}',
'Nguồn dài 265,9 giây, 384×848. Bản dựng chia theo thao tác và mô phỏng lại giao diện bằng nét vẽ để dễ đọc; không phải bản sao giao diện chính thức. Không đưa dữ liệu định danh, mật khẩu, OTP, số điện thoại, email, biển số, số khung, số máy thật vào bản dựng.',
'Không phát hành lại video gốc hoặc ảnh chụp gốc trong gói đầu ra vì có dữ liệu cá nhân và mã xác thực. Có bảng mốc cắt nguồn và MP4 riêng từng cảnh để chỉnh sửa.',
'','## Điểm đã kiểm tra từ video','',
'- Ví dụ: cấp đổi chứng nhận đăng ký xe vì thay đổi màu sơn. Không phải đăng ký xe lần đầu hoặc cấp lại do bị mất.',
'- Cuối nguồn có lỗi tải trang đồng thời thông báo SMS nói đăng ký hồ sơ thành công. Đây là thông báo về việc nộp/đăng ký hồ sơ, không phải kết luận đã cấp đổi xong. Bản dựng hướng dẫn lưu mã và tra cứu trước khi nộp lại.',
'- Không coi bảng lệ phí 0 trong nguồn là miễn phí mọi trường hợp. Không suy ra đã hoàn tất giấy tờ chỉ vì nguồn cuộn nhanh qua thành phần hồ sơ.',
'- Trường hợp thay đổi màu sơn có yêu cầu đưa xe đến kiểm tra theo quy định; không trình bày cấp đổi này là mọi khâu đều thực hiện tại nhà.',
'- Giữ trình tự thao tác của nguồn. Tên dịch vụ, thẩm quyền và yêu cầu thực tế phải theo phiên bản dịch vụ hiện hành; không khẳng định giao diện nguồn là giao diện mới nhất.',
'','## Nguồn đối chiếu ngày 21/10/2026','']
notes += [f'- [{title}]({url})' for title,url in SOURCES]
notes += ['','## Phân cảnh và lời đọc','']
for s in manifest:
 notes += [f'### {s["index"]:02}. {s["title"]} — {s["duration"]:.2f} giây',f'Mốc nguồn: {s["source"] if s["source"] else "Ghi chú bổ sung đối chiếu quy định"}.','',*s['sentences'],'']
notes += ['## Kỹ thuật và ghi công','',
'Tranh giao diện được vẽ lại theo video người dùng cung cấp, dữ liệu minh họa; không có logo cơ quan nhà nước. Hiệu ứng nét liên tục dùng srt-whiteboard-animation của geeklee (MIT). Giọng đọc tổng hợp Piper vi_VN-vais1000-medium qua sherpa-onnx; VAIS-1000 Vietnamese Speech Synthesis Corpus, CC BY 4.0 theo MODEL_CARD. Bàn tay minh họa không có thương hiệu.',
'Giọng đọc tốc độ 0,91; nghỉ giữa đoạn 0,7 giây; giữ hình ít nhất 4,5 giây sau lời đọc cuối mỗi cảnh. Phụ đề chia theo đoạn lời đọc, không phải karaoke từng từ.',
'Mô hình: https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-vi_VN-vais1000-medium.tar.bz2',
'Dữ liệu: https://ieee-dataport.org/documents/vais-1000-vietnamese-speech-synthesis-corpus',
'Giấy phép: https://creativecommons.org/licenses/by/4.0/','']
(ROOT/'KICH-BAN-VA-NGUON.md').write_text('\n'.join(notes))
print('TOTAL',round(offset,2),'s',flush=True)
