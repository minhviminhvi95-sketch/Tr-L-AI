from pathlib import Path
import sys,json,subprocess,math
import cv2
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'srt-whiteboard-animation/scripts'))
import render_stream_whiteboard as wb
import stream_render as sr
OUT=ROOT/'renders';OUT.mkdir(exist_ok=True)
FONT='/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf';BOLD='/usr/share/fonts/truetype/noto/NotoSans-Bold.ttf'
PAPER='#F5EBD7';INK='#373A3C';BLUE='#467DAB'
def font(size,bold=False):return ImageFont.truetype(BOLD if bold else FONT,size)
def wrap(text,limit,size,bold=False):
 d=ImageDraw.Draw(Image.new('RGB',(1,1)));lines=[];line=''
 for w in text.split():
  test=(line+' '+w).strip()
  if d.textlength(test,font=font(size,bold))>limit and line:lines.append(line);line=w
  else:line=test
 if line:lines.append(line)
 return lines
def ass_time(t):
 cs=round(t*100);s,cs=divmod(cs,100);m,s=divmod(s,60);h,m=divmod(m,60)
 return f'{h}:{m:02}:{s:02}.{cs:02}'
def tag_time(t):return f'{int(t)//60:02}:{int(t)%60:02}'
manifest=json.loads((ROOT/'manifest.json').read_text())
def make_ass(s):
 head='''[Script Info]
ScriptType: v4.00+
PlayResX: 1280
PlayResY: 720
WrapStyle: 2
ScaledBorderAndShadow: yes
[V4+ Styles]
Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding
Style: Caption,Noto Sans,29,&H003C3A37,&H003C3A37,&H00D7EBF5,&H00D7EBF5,0,0,0,0,100,100,0,0,1,2,0,2,80,80,55,1
Style: Text,Noto Sans,22,&H003C3A37,&H003C3A37,&H00D7EBF5,&H00D7EBF5,0,0,0,0,100,100,0,0,1,1,0,7,0,0,0,1
[Events]
Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text
'''
 events=[]
 def add(text,start,end,x=None,y=None,size=22,bold=False):
  if x is not None:
   position=f'{{\\pos({x},{y})\\fs{size}\\b{int(bold)}}}';style='Text'
  else:position='';style='Caption'
  events.append(f'Dialogue: 1,{ass_time(start)},{ass_time(end)},{style},,0,0,0,,{position}{text}')
 first=s['segments'][0]['start']
 ui_size=24
 while len(wrap(s['ui'],455,ui_size,True))>1:ui_size-=1
 add(s['ui'],first+.45,s['duration'],88,240,ui_size,True)
 for j,seg in enumerate(s['segments']):
  text='\\N'.join(wrap(s['fields'][j],431,21))
  add(text,seg['start']+.5,s['duration'],104,293+j*77,21)
  y=(244,374,484)[j]
  note='\\N'.join(wrap(s['notes'][j],484,26,True))
  add(note,seg['start']+.5,s['duration'],702,y,26,True)
  add(str(j+1),seg['start']+.4,s['duration'],653,y+1,24,True)
  words=seg['text'].split();groups=[];line=''
  for w in words:
   test=(line+' '+w).strip()
   if len(wrap(test,1100,29))>2:groups.append(line);line=w
   else:line=test
  if line:groups.append(line)
  if len(groups)>1 and len(groups[-1])<45:
   words=(groups[-2]+' '+groups[-1]).split();half=len(' '.join(words))/2
   k=min(range(1,len(words)),key=lambda k:abs(len(' '.join(words[:k]))-half))
   groups[-2:]=[' '.join(words[:k]),' '.join(words[k:])]
  at=seg['start'];total=sum(map(len,groups))
  for chunk in groups:
   span=seg['duration']*len(chunk)/total
   add('\\N'.join(wrap(chunk,1100,29)),at,at+span-.025)
   at+=span
 add(s['button'],s['segments'][2]['start']+.6,s['duration'],325,521,18,True)
 add('{\\fs23\\c&H00AB7D46&}'+s['tag'],s['segments'][-1]['end']+.3,s['duration'])
 return head+'\n'.join(events)+'\n'
def make_overlay(s):
 im=Image.new('RGBA',(1280,720),(0,0,0,0));d=ImageDraw.Draw(im)
 d.text((65,25),'VẼ TAY THEO VIDEO GỐC • CẤP ĐỔI ĐĂNG KÝ XE',font=font(16,True),fill=BLUE)
 d.text((1215,25),f'{s["index"]:02} / {len(manifest):02}',font=font(16,True),fill=BLUE,anchor='ra')
 size=34
 while d.textlength(s['title'],font=font(size,True))>1150:size-=1
 d.text((65,67),s['title'],font=font(size,True),fill=INK)
 tag_size=21
 while d.textlength(s['tag'],font=font(tag_size))>1150:tag_size-=1
 d.text((65,116),s['tag'],font=font(tag_size),fill=INK)
 d.line((65,157,1215,157),fill='#C8BDA6',width=1)
 d.rounded_rectangle((52,587,1228,672),radius=12,fill=(245,235,215,255))
 d.line((65,683,1215,683),fill='#C8BDA6',width=1)
 if s['source']:label='Mốc video gốc '+tag_time(s['source'][0])+'–'+tag_time(s['source'][1])
 else:label='Ghi chú đối chiếu quy định'
 d.text((65,691),label+' | Màn hình dựng lại • Dữ liệu minh họa | 21/10/2026',font=font(14),fill='#6E706D')
 d.line((65,715,1215,715),fill='#DDD2BD',width=4)
 d.line((65,715,65+round(1150*s['index']/len(manifest)),715),fill=BLUE,width=4)
 return im
def render(index):
 s=manifest[index-1];name=f'scene-{index:02}';final=OUT/f'{name}.mp4'
 if final.exists():print('SKIP',name,flush=True);return
 make_overlay(s).save(OUT/f'{name}-overlay.png');(OUT/f'{name}.ass').write_text(make_ass(s))
 ann=json.loads((ROOT/'art'/f'{name}.annotation.json').read_text())
 raw=OUT/f'{name}-raw.mp4'
 if not raw.exists():
  cfg=sr.Config(fps=24,grid_edge=8,cap_long_edge=1280,target_hand_height=160,canvas_hex=PAPER,ink_path_mode='skeleton',color_fill='contour-wipe',pause_mode='light')
  engine=wb.RegionStreamRenderer(cv2.imread(str(ROOT/'art'/f'{name}.png')),ann,cfg,ROOT/'hand.png',False)
  engine.render_to(raw,ann['sceneDurationMs'])
 cmd=['ffmpeg','-y','-v','error','-threads','2','-i',str(raw),'-i',str(OUT/f'{name}-overlay.png'),'-i',str(ROOT/'audio'/f'{name}.wav'),'-filter_complex',f'[0:v]crop=1280:412:0:170,pad=1280:720:0:170:color=0xF5EBD7[art];[art][1:v]overlay=0:0,ass={OUT}/{name}.ass[v];[2:a]loudnorm=I=-17:TP=-1.5:LRA=8,apad[a]',
 '-map','[v]','-map','[a]','-c:v','libx264','-preset','fast','-crf','20','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-ar','48000','-t',str(s['duration']),'-movflags','+faststart',str(final)]
 subprocess.run(cmd,check=True)
 print('RENDERED',name,round(s['duration'],2),flush=True)
if __name__=='__main__':
 for i in (list(map(int,sys.argv[1:])) or range(1,len(manifest)+1)):render(i)
