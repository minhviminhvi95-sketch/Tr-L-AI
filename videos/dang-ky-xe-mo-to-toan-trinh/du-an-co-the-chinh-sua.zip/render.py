from pathlib import Path
import sys,json,subprocess,re,math
import cv2
from PIL import Image,ImageDraw,ImageFont
from content import SCENES
ROOT=Path(__file__).resolve().parent
skill_scripts=ROOT/'vendor/whiteboard'
if not skill_scripts.exists():skill_scripts=ROOT.parent/'srt-whiteboard-animation/scripts'
sys.path.insert(0,str(skill_scripts))
import render_stream_whiteboard as wb
import stream_render as sr
OUT=ROOT/'renders';OUT.mkdir(exist_ok=True)
FONT='/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf'
BOLD='/usr/share/fonts/truetype/noto/NotoSans-Bold.ttf'
PAPER='#F5EBD7';INK='#373A3C';BLUE='#467DAB'
manifest=json.loads((ROOT/'manifest.json').read_text())

def font(size,bold=False): return ImageFont.truetype(BOLD if bold else FONT,size)
def wrap(text,limit,size):
    draw=ImageDraw.Draw(Image.new('RGB',(1,1)));lines=[];line=''
    for w in text.split():
        test=(line+' '+w).strip()
        if draw.textlength(test,font=font(size))>limit and line:lines.append(line);line=w
        else:line=test
    if line:lines.append(line)
    return lines
def ass_time(t):
    cs=round(t*100);s,cs=divmod(cs,100);m,s=divmod(s,60);h,m=divmod(m,60)
    return f'{h}:{m:02}:{s:02}.{cs:02}'
def ass_scene(scene):
    head='''[Script Info]
ScriptType: v4.00+
PlayResX: 1280
PlayResY: 720
WrapStyle: 2
ScaledBorderAndShadow: yes
[V4+ Styles]
Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding
Style: Caption,Noto Sans,29,&H003C3A37,&H003C3A37,&H00D7EBF5,&H00D7EBF5,0,0,0,0,100,100,0,0,1,2,0,2,80,80,58,1
Style: Label,Noto Sans,20,&H003C3A37,&H003C3A37,&H00D7EBF5,&H00D7EBF5,-1,0,0,0,100,100,0,0,1,1,0,8,0,0,0,1
[Events]
Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text
'''
    ev=[]
    for j,segment in enumerate(scene['segments']):
        size=20
        while len(wrap(scene['labels'][j],340,size))>2:size-=1
        label='\\N'.join(wrap(scene['labels'][j],340,size))
        ev.append(f'Dialogue: 1,{ass_time(segment["start"])},{ass_time(scene["duration"])},Label,,0,0,0,,{{\\fs{size}\\pos({215+j*402},524)}}{label}')
        # Each cue contains no more than two lines; sentence-level voice boundaries are exact.
        words=segment['text'].split();chunks=[];part=''
        for word in words:
            proposed=(part+' '+word).strip()
            if len(wrap(proposed,1090,29))>2:
                chunks.append(part);part=word
            else:part=proposed
        if part:chunks.append(part)
        if len(chunks)>1 and len(chunks[-1])<45:
            words=(chunks[-2]+' '+chunks[-1]).split()
            half=len(' '.join(words))/2
            split=min(range(1,len(words)),key=lambda k:abs(len(' '.join(words[:k]))-half))
            chunks[-2:]=[' '.join(words[:split]),' '.join(words[split:])]
        total=sum(len(t) for t in chunks);at=segment['start']
        for chunk in chunks:
            span=segment['duration']*len(chunk)/total
            text='\\N'.join(wrap(chunk,1090,29))
            ev.append(f'Dialogue: 2,{ass_time(at)},{ass_time(at+span-0.025)},Caption,,0,0,0,,{text}')
            at+=span
    # A useful readout remains on screen during the final four-second pause.
    final_end=scene['segments'][-1]['end']
    ev.append(f'Dialogue: 2,{ass_time(final_end+0.25)},{ass_time(scene["duration"])},Caption,,0,0,0,,{{\\fs24\\c&H00AB7D46&}}'+scene['tag'])
    return head+'\n'.join(ev)+'\n'

def header(scene):
    im=Image.new('RGBA',(1280,720),(0,0,0,0));d=ImageDraw.Draw(im)
    d.text((65,27),'HƯỚNG DẪN ĐĂNG KÝ XE MÔ TÔ',font=font(16,True),fill=BLUE)
    d.text((1215,27),f'{scene["index"]:02} / {len(manifest):02}',font=font(16,True),fill=BLUE,anchor='ra')
    size=36
    while d.textlength(scene['title'],font=font(size,True))>1150:size-=1
    d.text((65,69),scene['title'],font=font(size,True),fill=INK)
    d.text((65,121),scene['tag'],font=font(21),fill=INK)
    d.line((65,163,1215,163),fill='#C8BDA6',width=1)
    d.rounded_rectangle((53,589,1227,670),radius=12,fill=(245,235,215,245))
    d.line((65,680,1215,680),fill='#C8BDA6',width=1)
    footer='Nguồn: Bộ Công an • Cổng TTĐT Chính phủ | Đối chiếu 20/10/2026 | Minh họa độc lập'
    d.text((65,689),footer,font=font(14),fill='#6E706D')
    d.line((65,714,1215,714),fill='#DDD2BD',width=4)
    d.line((65,714,65+round(1150*scene['index']/len(manifest)),714),fill=BLUE,width=4)
    return im

def render(index):
    scene=manifest[index-1];n=f'scene-{index:02}'
    final=OUT/f'{n}.mp4'
    if final.exists():print('SKIP',n,flush=True);return
    header(scene).save(OUT/f'{n}-overlay.png')
    (OUT/f'{n}.ass').write_text(ass_scene(scene))
    ann=json.loads((ROOT/'art'/f'{n}.annotation.json').read_text())
    source=cv2.imread(str(ROOT/'art'/f'{n}.png'))
    cfg=sr.Config(fps=24,grid_edge=8,cap_long_edge=1280,target_hand_height=180,
        canvas_hex=PAPER,ink_path_mode='skeleton',color_fill='contour-wipe',pause_mode='light')
    raw=OUT/f'{n}-raw.mp4'
    if not raw.exists():
        renderer=wb.RegionStreamRenderer(source,ann,cfg,ROOT/'art/hand.png',False)
        renderer.render_to(raw,ann['sceneDurationMs'])
    cmd=['ffmpeg','-y','-v','error','-threads','2','-i',str(raw),'-i',str(OUT/f'{n}-overlay.png'),
        '-i',str(ROOT/'audio'/f'{n}.wav'),'-filter_complex',
        f'[0:v]crop=1280:355:0:165,pad=1280:720:0:165:color=0xF5EBD7[art];[art][1:v]overlay=0:0,ass={OUT}/{n}.ass[v];[2:a]loudnorm=I=-17:TP=-1.5:LRA=8,apad[a]',
        '-map','[v]','-map','[a]','-c:v','libx264','-preset','fast','-crf','20','-pix_fmt','yuv420p',
        '-c:a','aac','-b:a','160k','-ar','48000','-t',f'{scene["duration"]:.6f}',
        '-movflags','+faststart',str(final)]
    subprocess.run(cmd,check=True)
    print('RENDERED',n,scene['duration'],flush=True)

if __name__=='__main__':
    for index in (list(map(int,sys.argv[1:])) or range(1,len(manifest)+1)):render(index)
