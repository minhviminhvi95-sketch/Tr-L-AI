from pathlib import Path
import json, math, re, sys
import numpy as np
import sherpa_onnx
import soundfile as sf
from content import SCENES, SOURCES

ROOT=Path(__file__).resolve().parent
AUDIO=ROOT/'audio';AUDIO.mkdir(exist_ok=True)
model=ROOT/'models/vits-piper-vi_VN-vais1000-medium'
config=sherpa_onnx.OfflineTtsConfig(model=sherpa_onnx.OfflineTtsModelConfig(
    vits=sherpa_onnx.OfflineTtsVitsModelConfig(model=str(model/'vi_VN-vais1000-medium.onnx'),
    tokens=str(model/'tokens.txt'),data_dir=str(model/'espeak-ng-data')),num_threads=2))
tts=sherpa_onnx.OfflineTts(config)
sr=22050;manifest=[];offset=0
def tc(sec):
    ms=round(sec*1000);s,ms=divmod(ms,1000);m,s=divmod(s,60);h,m=divmod(m,60)
    return f'{h:02}:{m:02}:{s:02},{ms:03}'
def chunks(text,limit=79):
    result=[];line=''
    for word in text.split():
        if len(line)+len(word)+1>limit:
            result.append(line);line=word
        else:line=(line+' '+word).strip()
    if line:result.append(line)
    if len(result)>1 and len(result[-1])<32:
        words=(result[-2]+' '+result[-1]).split()
        half=len(' '.join(words))/2
        split=min(range(1,len(words)),key=lambda k:abs(len(' '.join(words[:k]))-half))
        result[-2:]=[' '.join(words[:split]),' '.join(words[split:])]
    return result
srt=[];srt_count=0
for index,scene in enumerate(SCENES,1):
    cursor=0.65;segments=[];parts=[np.zeros(round(cursor*sr),dtype=np.float32)]
    for j,text in enumerate(scene['sentences']):
        wav=AUDIO/f'scene-{index:02}-sentence-{j+1}.wav'
        if wav.exists():samples,rate=sf.read(wav,dtype='float32')
        else:
            spoken=text.replace('VNeID','vi en ai đi')
            generated=tts.generate(spoken,sid=0,speed=0.93)
            samples=generated.samples;rate=generated.sample_rate
            assert rate==sr
            peak=np.max(np.abs(samples));samples=np.asarray(samples)*min(1.,0.91/max(peak,1e-5))
            sf.write(wav,samples,sr)
        duration=len(samples)/sr
        segments.append(dict(text=text,start=cursor,end=cursor+duration,duration=duration))
        c=chunks(text);total=sum(len(x) for x in c);at=cursor
        for sentence in c:
            span=duration*len(sentence)/total
            srt_count+=1;srt.append(f'{srt_count}\n{tc(offset+at)} --> {tc(offset+at+span-0.035)}\n{sentence}\n')
            at+=span
        parts.extend([samples,np.zeros(round(0.65*sr),dtype=np.float32)])
        cursor+=duration+0.65
    # Four seconds of silence after speech, not overlapping the final readout.
    exact=math.ceil((cursor+3.35)*24)/24
    sound=np.concatenate(parts+[np.zeros(max(0,round(exact*sr)-sum(len(p) for p in parts)),dtype=np.float32)])
    sf.write(AUDIO/f'scene-{index:02}.wav',sound,sr)
    scene_out={**scene,'index':index,'segments':segments,'duration':len(sound)/sr,'offset':offset}
    manifest.append(scene_out);offset+=len(sound)/sr
    ann={'sceneId':f'scene-{index:02}','canvas':{'width':1280,'height':720},
    'storyBasis':' '.join(scene['sentences']),'sceneDurationMs':round(len(sound)*1000/sr),'elements':[]}
    for j,seg in enumerate(segments):
        x=43+j*402
        ann['elements'].append({'id':f'event-{j+1}','label':scene['labels'][j],'sequence':j+1,
        'narrativeRole':f'Ý thứ {j+1} theo lời đọc','subtitle':seg['text'],'type':scene['icons'][j],
        'region':{'x':x,'y':180,'width':397,'height':355},
        'reveal':{'direction':'top_to_bottom','startMs':round(seg['start']*1000),
        'durationMs':round(max(2, min(seg['duration']*0.70,8.0))*1000),'maskPaddingPx':0,'protectedRegions':[]},
        'handPath':{'start':[x+100,220],'end':[x+270,480],'easing':'easeInOut'}})
    (ROOT/'art'/f'scene-{index:02}.annotation.json').write_text(json.dumps(ann,ensure_ascii=False,indent=2))
    print(f'SCENE {index:02}: {scene_out["duration"]:.2f}s',flush=True)
(ROOT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
(ROOT/'phu-de.srt').write_text('\n'.join(srt),encoding='utf-8')
notes=['# Đăng ký xe mô tô lần đầu trực tuyến toàn trình','',
'Phạm vi: xe mới sản xuất, lắp ráp trong nước và xe mới nhập khẩu; chủ xe là công dân Việt Nam đủ điều kiện. Không hướng dẫn sang tên xe cũ.','',
'Đối chiếu nguồn chính thức: 20/10/2026. Đây là video hướng dẫn độc lập, không phải video do cơ quan nhà nước phát hành. Giao diện minh họa, tên trường và thao tác thực tế có thể thay đổi.','',
'## Nguồn pháp lý và hướng dẫn','']
notes += [f'- [{title}]({url})' for title,url in SOURCES]
notes += ['', 'Các trang dịch vụ cũ còn hiển thị mã thủ tục, thẩm quyền cấp huyện, thông tư lệ phí cũ hoặc thời hạn khác. Video dùng Quyết định 4685/QĐ-BCA-C08 và văn bản sửa đổi năm 2026 cho thủ tục thống nhất và thời hạn; chỉ đối chiếu thông tin giấy tờ chuyên biệt từ trang hướng dẫn cũ.',
'Không khẳng định xe mới được miễn trước bạ hoặc miễn lệ phí cấp mới biển số. Không đưa mức tiền cố định khi chưa biết giá tính lệ phí, địa bàn và điều kiện miễn giảm.',
'','## Phân cảnh và lời đọc','']
for s in manifest:
    notes += [f'### {s["index"]:02}. {s["title"]} — {s["duration"]:.2f} giây','',*s['sentences'],'']
notes += ['## Kỹ thuật và bản quyền','',
'Tranh vector và bàn tay minh họa được vẽ mới cho video; nền giấy #F5EBD7. Dựng nét liên tục bằng skill srt-whiteboard-animation (MIT), commit 696a7243c0e6ffb6827676e539c2ca5ebae2bf6b. Không sử dụng logo hoặc giao diện giả mạo cơ quan nhà nước.',
'Giọng đọc tổng hợp chạy cục bộ: Piper vi_VN-vais1000-medium qua sherpa-onnx. Bộ dữ liệu VAIS-1000 Vietnamese Speech Synthesis Corpus, giấy phép CC BY 4.0 theo MODEL_CARD. Tốc độ tổng hợp 0.93; nghỉ 0.65 giây giữa các đoạn và giữ hình ít nhất 4 giây sau lời đọc cuối mỗi cảnh.',
'Mô hình: https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-vi_VN-vais1000-medium.tar.bz2',
'Dữ liệu: https://ieee-dataport.org/documents/vais-1000-vietnamese-speech-synthesis-corpus',
'Giấy phép dữ liệu: https://creativecommons.org/licenses/by/4.0/','']
(ROOT/'KICH-BAN-VA-NGUON.md').write_text('\n'.join(notes))
print(f'TOTAL {offset:.2f}s; subtitles {srt_count}',flush=True)
