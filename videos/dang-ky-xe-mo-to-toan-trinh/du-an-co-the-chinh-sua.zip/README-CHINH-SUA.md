# Dự án video đăng ký xe mô tô

Video 1280×720, 24 fps, H.264/AAC; 12 cảnh và bảng nguồn cuối phim. Tổng thời lượng khoảng 5 phút 15 giây. Đã có tranh, lời đọc từng câu, WAV từng cảnh, phụ đề SRT, thời gian và JSON vùng vẽ.

1. Đọc `KICH-BAN-VA-NGUON.md` trước khi sửa nội dung pháp luật.
2. Sửa tiêu đề, câu đọc, nhãn trong `content.py`.
3. Tạo môi trường Python riêng; cài `numpy opencv-python Pillow av cairosvg sherpa-onnx soundfile`. Cần FFmpeg trong PATH và thư viện Cairo cho CairoSVG. Bộ dựng hiện dùng phông Noto Sans tại đường dẫn Linux; thay FONT/BOLD trong render.py và đường dẫn phông trong make_art.py/finish.py để phù hợp máy đích.
4. Nếu chỉ dùng lại giọng đọc đã có, giữ `audio/` và `manifest.json`, chạy `python render.py`, rồi `python finish.py`. Xóa MP4 của cảnh cần render lại trong `renders/`; nếu tranh hoặc vùng vẽ thay đổi, xóa cả `scene-XX-raw.mp4` tương ứng.
5. Nếu cần tạo lại giọng đọc, tải mô hình từ URL trong tài liệu nguồn, giải nén vào `models/`, xóa WAV câu/cảnh bị sửa rồi chạy `python prepare.py` trước khi render. Không phát hành gói này như một ứng dụng cài sẵn đa nền tảng.

`vendor/whiteboard` chứa hai mô-đun renderer từ geeklee/srt-whiteboard-animation (MIT). Các file nguồn gốc và giấy phép được giữ kèm. Mô hình giọng đọc cần tải riêng, không có trong gói chỉnh sửa.

Lưu ý: không sao chép thông tin ngày đối chiếu 20/10/2026 sang video dùng cho thời điểm khác mà chưa kiểm tra lại quy định. Video minh họa độc lập, không mô phỏng đăng nhập thật hoặc xử lý dữ liệu cá nhân.
