from pathlib import Path
import json,subprocess,shutil,zipfile
from PIL import Image,ImageDraw,ImageFont
from content import SOURCES
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'renders';DELIVERY=ROOT/'delivery';DELIVERY.mkdir(exist_ok=True)
font_root=Path('/usr/share/fonts/truetype/noto')
def f(size,bold=False):return ImageFont.truetype(str(font_root/('NotoSans-Bold.ttf' if bold else 'NotoSans-Regular.ttf')),size)
im=Image.new('RGB',(1280,720),'#F5EBD7');d=ImageDraw.Draw(im)
d.text((70,44),'CĂN CỨ VÀ NGUỒN ĐỐI CHIẾU',font=f(36,True),fill='#373A3C')
d.text((70,100),'Đối chiếu ngày 20/10/2026 • Nguồn chính thức của cơ quan nhà nước',font=f(22),fill='#467DAB')
items=[('01','Quyết định 4685/QĐ-BCA-C08 · 23/7/2026','Thủ tục đăng ký xe thống nhất, các hình thức và thời hạn.'),
('02','Thông tư 79/2024/TT-BCA và các văn bản sửa đổi','Điều kiện toàn trình, giấy tờ xe trong nước và xe nhập khẩu.'),
('03','Thông tư 51/2025, 37/2026, 62/2026 của Bộ Công an','Thẩm quyền, nhận kết quả, dữ liệu điện tử và thời hạn.'),
('04','Thông tư 155/2025 và 117/2026 của Bộ Tài chính','Lệ phí đăng ký, cấp biển và điều kiện miễn, giảm liên quan.')]
for j,(num,title,desc) in enumerate(items):
    y=174+j*100
    d.rounded_rectangle((70,y,118,y+46),radius=10,fill='#467DAB')
    d.text((94,y+7),num,font=f(21,True),fill='#F5EBD7',anchor='ma')
    d.text((143,y-2),title,font=f(24,True),fill='#373A3C')
    d.text((143,y+37),desc,font=f(21),fill='#6E706D')
d.line((70,601,1210,601),fill='#C8BDA6',width=1)
d.text((70,624),'Đường dẫn nguồn và toàn bộ lời đọc: xem tệp KICH-BAN-VA-NGUON.md đi kèm.',font=f(23),fill='#373A3C')
d.text((70,676),'Video hướng dẫn độc lập • Hình minh họa • Giọng đọc tổng hợp',font=f(16),fill='#6E706D')
im.save(OUT/'credits.png')
subprocess.run(['ffmpeg','-y','-v','error','-loop','1','-framerate','24','-i',str(OUT/'credits.png'),
'-f','lavfi','-i','anullsrc=r=48000:cl=mono','-t','14','-c:v','libx264','-preset','fast','-crf','20',
'-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-movflags','+faststart',str(OUT/'credits.mp4')],check=True)
files=[OUT/f'scene-{i:02}.mp4' for i in range(1,13)]+[OUT/'credits.mp4']
assert all(p.exists() for p in files)
(OUT/'concat.txt').write_text('\n'.join("file '"+str(p)+"'" for p in files)+'\n')
final=DELIVERY/'dang-ky-xe-mo-to-toan-trinh.mp4'
subprocess.run(['ffmpeg','-y','-v','error','-f','concat','-safe','0','-i',str(OUT/'concat.txt'),'-c','copy',
'-movflags','+faststart','-metadata','title=Đăng ký xe mô tô lần đầu trực tuyến toàn trình',
'-metadata','comment=Nguồn chính thức đối chiếu 20/10/2026; xe trong nước và xe nhập khẩu; minh họa độc lập.',str(final)],check=True)
for name in ['phu-de.srt','KICH-BAN-VA-NGUON.md']:
    shutil.copy2(ROOT/name,DELIVERY/name)
manifest=json.loads((ROOT/'manifest.json').read_text())
chapters=[';FFMETADATA1']
for s in manifest:
    chapters += ['[CHAPTER]','TIMEBASE=1/1000',f'START={round(s["offset"]*1000)}',f'END={round((s["offset"]+s["duration"])*1000)}','title='+s['title']]
(ROOT/'chapters.txt').write_text('\n'.join(chapters))
chaptered=DELIVERY/'with-chapters.mp4'
subprocess.run(['ffmpeg','-y','-v','error','-i',str(final),'-i',str(ROOT/'chapters.txt'),'-map_metadata','0','-map_chapters','1','-c','copy','-movflags','+faststart',str(chaptered)],check=True)
chaptered.replace(final)
subprocess.run(['ffmpeg','-y','-v','error','-ss','23','-i',str(final),'-frames:v','1',str(DELIVERY/'anh-xem-truoc.jpg')],check=True)
with zipfile.ZipFile(DELIVERY/'giong-doc-tung-canh.zip','w',zipfile.ZIP_DEFLATED) as z:
    for i in range(1,13):
        p=ROOT/'audio'/f'scene-{i:02}.wav';z.write(p,p.name)
with zipfile.ZipFile(DELIVERY/'du-an-co-the-chinh-sua.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in [ROOT/'content.py',ROOT/'make_art.py',ROOT/'prepare.py',ROOT/'render.py',ROOT/'finish.py',ROOT/'manifest.json',ROOT/'phu-de.srt',ROOT/'KICH-BAN-VA-NGUON.md',ROOT/'README-CHINH-SUA.md',ROOT/'requirements-verified.txt']:
        z.write(p,p.name)
    for folder in ['art','audio']:
        for p in (ROOT/folder).glob('*'):
            if p.is_file():z.write(p,str(p.relative_to(ROOT)))
    for p in (ROOT/'vendor').rglob('*'):
        if p.is_file() and '__pycache__' not in p.parts:z.write(p,str(p.relative_to(ROOT)))
print('FINAL',final)
for p in DELIVERY.iterdir():print(p.name,p.stat().st_size)
