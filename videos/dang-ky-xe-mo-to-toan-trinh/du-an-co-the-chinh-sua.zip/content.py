SCENES = [
dict(title='ĐĂNG KÝ XE MÔ TÔ TOÀN TRÌNH', tag='Đăng ký lần đầu • Cá nhân Việt Nam', icons=['motorcycle','factory','ship'], labels=['XE MỚI','TRONG NƯỚC','NHẬP KHẨU'], sentences=[
'Bạn mua xe mô tô mới và muốn đăng ký trực tuyến toàn trình? Hướng dẫn này dành cho công dân Việt Nam đăng ký xe lần đầu.',
'Xe sản xuất, lắp ráp trong nước và xe nhập khẩu có thể thực hiện toàn trình khi đáp ứng điều kiện.',
'Chúng ta sẽ đi từ chuẩn bị hồ sơ đến nhận đăng ký và biển số. Nội dung được đối chiếu nguồn chính thức ngày hai mươi tháng mười năm hai nghìn không trăm hai mươi sáu.']),
dict(title='01 / KIỂM TRA ĐIỀU KIỆN', tag='Tài khoản mức 2 + dữ liệu điện tử đầy đủ', icons=['phone','cloud','shield'],labels=['VNeID MỨC 2','DỮ LIỆU ĐIỆN TỬ','ĐỐI CHIẾU THÔNG TIN'],sentences=[
'Trước hết, cần tài khoản định danh điện tử mức độ hai để đăng nhập và kê khai.',
'Kiểm tra dữ liệu nguồn gốc xe, hóa đơn điện tử và lệ phí trước bạ đã có đầy đủ, khớp với thông tin chủ xe và phương tiện.',
'Nếu dữ liệu thiếu hoặc sai, liên hệ bên bán và cơ quan liên quan để điều chỉnh. Chọn hình thức toàn trình khi hồ sơ và hệ thống đáp ứng điều kiện.']),
dict(title='02A / XE SẢN XUẤT TRONG NƯỚC',tag='Giữ giấy tờ nguồn gốc để nộp khi nhận kết quả',icons=['factory','document','stamp'],labels=['CƠ SỞ SẢN XUẤT','PHIẾU XUẤT XƯỞNG','BẢN CHÀ + GIÁP LAI'],sentences=[
'Với xe sản xuất, lắp ráp trong nước, giấy tờ cần lưu ý là phiếu kiểm tra chất lượng xuất xưởng.',
'Phiếu phải có bản chà số máy, số khung và dấu giáp lai của cơ sở sản xuất theo quy định.',
'Nếu không có bản giấy, dùng bản in từ cơ sở dữ liệu điện tử, có dán bản chà và đóng dấu giáp lai đúng yêu cầu. Giữ giấy tờ để nộp khi nhận kết quả.']),
dict(title='02B / XE NHẬP KHẨU',tag='Giấy tờ nhập khẩu khác phiếu xuất xưởng trong nước',icons=['ship','document','stamp'],labels=['NGUỒN GỐC NHẬP KHẨU','CHỨNG NHẬN / MIỄN KIỂM TRA','GIÁP LAI ĐƠN VỊ NHẬP KHẨU'],sentences=[
'Với xe nhập khẩu, kiểm tra dữ liệu nguồn gốc hải quan, hóa đơn và lệ phí trước bạ.',
'Chuẩn bị giấy chứng nhận chất lượng an toàn kỹ thuật và bảo vệ môi trường xe nhập khẩu, hoặc thông báo miễn kiểm tra tương ứng.',
'Giấy tờ phải có bản chà số máy, số khung và dấu giáp lai của đơn vị nhập khẩu. Nếu không có bản giấy, dùng bản in từ cơ sở dữ liệu điện tử đáp ứng cùng yêu cầu.']),
dict(title='03 / HOÀN THÀNH LỆ PHÍ TRƯỚC BẠ',tag='Trước bạ và đăng ký, cấp biển là hai khoản khác nhau',icons=['document','wallet','cloud'],labels=['KÊ KHAI TRƯỚC BẠ','NGHĨA VỤ TÀI CHÍNH','KIỂM TRA DỮ LIỆU'],sentences=[
'Kê khai lệ phí trước bạ qua kênh điện tử của cơ quan thuế hoặc kênh được hướng dẫn, và hoàn thành nghĩa vụ theo thông báo.',
'Lệ phí trước bạ khác với lệ phí đăng ký, cấp biển số. Không dùng một mức tiền chung cho mọi xe và mọi trường hợp.',
'Lưu chứng từ và kiểm tra dữ liệu đã được kết nối. Các chính sách miễn, giảm chỉ áp dụng khi đáp ứng đúng điều kiện.']),
dict(title='04 / ĐĂNG NHẬP VÀ CHỌN DỊCH VỤ',tag='Cổng Dịch vụ công quốc gia hoặc VNeID',icons=['phone','document','building'],labels=['ĐĂNG NHẬP CHÍNH THỨC','ĐĂNG KÝ XE LẦN ĐẦU','CHỌN ĐÚNG THẨM QUYỀN'],sentences=[
'Truy cập Cổng Dịch vụ công quốc gia hoặc ứng dụng định danh quốc gia, đăng nhập bằng tài khoản định danh điện tử mức độ hai.',
'Tìm dịch vụ đăng ký, cấp chứng nhận đăng ký xe, biển số xe. Chọn nội dung đăng ký lần đầu, đúng nguồn gốc xe và hình thức toàn trình theo giao diện hiện hành.',
'Chọn cơ quan đăng ký có thẩm quyền. Cá nhân trong nước được lựa chọn Phòng Cảnh sát giao thông hoặc Công an cấp xã trong tỉnh, thành phố nơi mình cư trú theo quy định.']),
dict(title='05 / KÊ KHAI VÀ ĐỐI CHIẾU',tag='Thông tin chủ xe • Số máy • Số khung • Hóa đơn',icons=['person','motorcycle','document'],labels=['ĐÚNG CHỦ XE','ĐÚNG PHƯƠNG TIỆN','ĐÚNG HỒ SƠ'],sentences=[
'Kê khai chính xác, đầy đủ và trung thực thông tin chủ xe. Kiểm tra cả những dữ liệu hệ thống tự điền.',
'Đối chiếu nhãn hiệu, loại xe, số máy, số khung và các thông tin liên quan với giấy tờ nguồn gốc, hóa đơn.',
'Bổ sung tài liệu hoặc hình ảnh mà dịch vụ yêu cầu. Chọn cách nhận kết quả phù hợp, kiểm tra địa chỉ và thông tin liên hệ trước khi gửi.']),
dict(title='06 / GỬI HỒ SƠ VÀ THEO DÕI',tag='Lưu mã hồ sơ; xử lý yêu cầu bổ sung nếu có',icons=['cloud','magnify','phone'],labels=['GỬI HỒ SƠ','CƠ QUAN KIỂM TRA','THEO DÕI PHẢN HỒI'],sentences=[
'Gửi hồ sơ và lưu mã hồ sơ điện tử để tra cứu. Theo dõi thông báo trên cổng dịch vụ công, ứng dụng hoặc kênh liên hệ đã đăng ký.',
'Cơ quan đăng ký tiếp nhận, kiểm tra tính hợp lệ và đối chiếu dữ liệu. Nếu cần bổ sung, thực hiện đúng nội dung được hướng dẫn.',
'Thông báo gửi hồ sơ thành công chưa có nghĩa là đã được cấp đăng ký. Chỉ chuyển sang bước tiếp theo khi hệ thống có hướng dẫn phù hợp.']),
dict(title='07 / BIỂN SỐ VÀ LỆ PHÍ ĐĂNG KÝ',tag='Thực hiện theo trạng thái hồ sơ và hướng dẫn hệ thống',icons=['plate','wallet','shield'],labels=['BIỂN SỐ THEO TRƯỜNG HỢP','THANH TOÁN TÍCH HỢP','LƯU XÁC NHẬN'],sentences=[
'Khi được hướng dẫn, thực hiện lựa chọn biển định danh, xác nhận biển trúng đấu giá hoặc bấm biển số mới theo trường hợp của mình.',
'Nộp lệ phí đăng ký, cấp biển số qua tiện ích thanh toán chính thức được tích hợp. Kiểm tra số tiền và nội dung trước khi xác nhận.',
'Lưu xác nhận thanh toán. Nếu chọn chuyển phát, theo dõi cả chi phí dịch vụ bưu chính; khoản này khác với lệ phí đăng ký xe.']),
dict(title='08 / HIỂU ĐÚNG THỜI HẠN',tag='Hồ sơ hợp lệ + hoàn thành nghĩa vụ tài chính',icons=['calendar','plate','truck'],labels=['ĐĂNG KÝ: TỐI ĐA 2 NGÀY LÀM VIỆC','BIỂN ĐỊNH DANH / ĐẤU GIÁ: TỐI ĐA 7 NGÀY LÀM VIỆC','CHUYỂN PHÁT TÍNH RIÊNG'],sentences=[
'Thời hạn cấp mới chứng nhận đăng ký xe không quá hai ngày làm việc kể từ khi nhận đủ hồ sơ hợp lệ.',
'Biển số cấp mới được cấp ngay sau khi hồ sơ hợp lệ; cấp biển định danh hoặc biển trúng đấu giá không quá bảy ngày làm việc theo quy định.',
'Thời hạn được tính khi đã nhận đủ hồ sơ hợp lệ và hoàn thành nghĩa vụ tài chính. Không cộng đồng thời các mốc này một cách máy móc; thời gian chuyển phát kết quả là phần riêng.']),
dict(title='09 / NHẬN KẾT QUẢ VÀ NỘP GIẤY TỜ',tag='Nộp đúng giấy tờ nguồn gốc của từng loại xe',icons=['truck','document','magnify'],labels=['NHẬN ĐĂNG KÝ + BIỂN','NỘP GIẤY TỜ ĐÚNG LOẠI','THIẾU / SAI: KIỂM TRA XE'],sentences=[
'Nhận chứng nhận đăng ký và biển số theo lựa chọn, đồng thời nộp giấy tờ nguồn gốc có bản chà và dấu giáp lai đúng loại xe.',
'Xe trong nước nộp phiếu kiểm tra chất lượng xuất xưởng; xe nhập khẩu nộp giấy chứng nhận chất lượng hoặc thông báo miễn kiểm tra tương ứng.',
'Nếu không nộp giấy tờ hoặc bản chà số máy, số khung không khớp thông tin kê khai, phải đưa xe đến cơ quan đăng ký để kiểm tra và nhận kết quả.']),
dict(title='HOÀN TẤT / KIỂM TRA VÀ LƯU HỒ SƠ',tag='Nguồn chính thức đối chiếu ngày 20/10/2026',icons=['shield','phone','motorcycle'],labels=['KIỂM TRA KẾT QUẢ','LƯU DỮ LIỆU + BIÊN NHẬN','HOÀN TẤT ĐĂNG KÝ'],sentences=[
'Kiểm tra thông tin chủ xe, phương tiện và biển số trên kết quả được cấp. Nếu phát hiện sai, liên hệ cơ quan đăng ký để được hướng dẫn.',
'Theo dõi dữ liệu chứng nhận đăng ký điện tử được tích hợp trên ứng dụng định danh quốc gia hoặc ứng dụng giao thông của Bộ Công an khi được cập nhật.',
'Tóm lại: đúng điều kiện, đúng hồ sơ, đúng nghĩa vụ tài chính và đúng giấy tờ khi nhận kết quả. Toàn trình không có nghĩa là mọi trường hợp đều được bỏ qua việc đối chiếu hoặc kiểm tra xe.'])
]

SOURCES = [
('Quyết định 4685/QĐ-BCA-C08 ngày 23/7/2026: thủ tục thống nhất, hình thức toàn trình, thời hạn', 'https://congan.khanhhoa.gov.vn/FileStorage/images/phapche/Q%C4%90%20TTHC/4685-Q%C4%90-BCA.pdf'),
('Bộ Công an: Thông tư 79/2024; điều kiện toàn trình, giấy tờ nguồn gốc', 'https://bocongan.gov.vn/chinh-sach-phap-luat/bai-viet/quy-dinh-ve-cap-thu-hoi-chung-nhan-dang-ky-xe-bien-so-xe-co-gioi-xe-may-chuyen-dung-d1-t1591'),
('Cổng DVC Bộ Công an: dữ liệu, giấy tờ xe nhập khẩu và ngoại lệ kiểm tra xe; không dùng phần thẩm quyền, lệ phí, thời hạn cũ', 'https://dichvucong.bocongan.gov.vn/bocongan/bothutuc/tthc?matt=64193'),
('Bộ Công an: lựa chọn cơ quan đăng ký theo Thông tư 51/2025', 'https://bocongan.gov.vn/bai-viet/to-chuc-ca-nhan-trong-nuoc-duoc-lua-chon-dang-ky-xe-tai-phong-canh-sat-giao-thong-hoac-cong-an-cap-xa-d1-t1770'),
('Chính phủ: Thông tư 37/2026 về nhận kết quả và tích hợp dữ liệu điện tử', 'https://xaydungchinhsach.chinhphu.vn/toan-van-thong-tu-so-37-2026-tt-bca-ve-dang-ky-kiem-dinh-phuong-tien-119260429143832445.htm'),
('Công báo: Thông tư 62/2026, Điều 7 sửa thời hạn và hình thức nhận kết quả', 'https://congbao.chinhphu.vn/van-ban/thong-tu-so-62-2026-tt-bca-469658.htm'),
('Chính phủ: Thông tư 155/2025 về lệ phí đăng ký, cấp biển, hiệu lực 1/1/2026', 'https://chinhphu.vn/?classid=1&docid=216546&pageid=27160&typegroupid=6'),
('Chính phủ: Thông tư 117/2026, miễn giảm chỉ áp dụng các trường hợp và điều kiện quy định, không mặc định xe mới được miễn', 'https://xaydungchinhsach.chinhphu.vn/toan-van-thong-tu-117-2026-tt-btc-quy-dinh-mien-giam-mot-so-khoan-phi-le-phi-de-trien-khai-nghi-quyet-ve-phat-trien-cong-dan-so-119260828175124756.htm'),
]
