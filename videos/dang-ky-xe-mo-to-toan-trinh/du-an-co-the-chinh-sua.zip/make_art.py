from pathlib import Path
import cairosvg
from PIL import Image, ImageDraw, ImageFont
from content import SCENES

ROOT=Path(__file__).resolve().parent
ART=ROOT/'art'; ART.mkdir(exist_ok=True)
INK='#373A3C'; BLUE='#467DAB'; RED='#BE5949'; ORANGE='#CE9151'; PAPER='#F5EBD7'

def path(d, color=INK, width=4, fill='none'):
    return f'<path d="{d}" stroke="{color}" stroke-width="{width}" fill="{fill}" stroke-linecap="round" stroke-linejoin="round"/>'
def circle(x,y,r,color=INK,fill='none',width=4):
    return f'<circle cx="{x}" cy="{y}" r="{r}" stroke="{color}" stroke-width="{width}" fill="{fill}"/>'
def rect(x,y,w,h,color=INK,fill='none',r=10,width=4):
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" stroke="{color}" stroke-width="{width}" fill="{fill}"/>'
def check(x=110,y=120): return path(f'M{x-28} {y} l20 22 l45 -55',BLUE,7)
def icon(name):
    if name=='motorcycle':
        return circle(55,190,40)+circle(235,190,40)+circle(55,190,25,width=2)+circle(235,190,25,width=2)+path('M55 190 L112 130 L171 190 L55 190 M112 130 L150 115 L204 120 L235 190 M172 190 L211 131 M207 118 L195 80 L173 75 M85 114 L153 114',width=6)+path('M126 133 Q147 112 183 130 L169 161 L134 161 Z',BLUE,4,'#D8DFDC')+rect(111,161,47,35,r=5,fill=PAPER)+path('M117 169 L151 169 M117 178 L151 178 M125 198 L125 207 L65 207 M62 211 L102 211 M18 159 Q45 129 81 149 M207 151 Q239 133 267 158',INK,4)+rect(201,91,21,24,r=5)+path('M42 236 Q146 242 275 236',INK,2)
    if name=='factory':
        return path('M30 220 L30 119 L93 87 L93 119 L156 87 L156 119 L235 119 L235 220 Z')+rect(209,37,25,82,r=2)+path('M215 22 Q194 5 213 -6 M238 23 Q260 5 243 -13',INK,3)+rect(55,153,28,29,BLUE,r=2)+rect(110,153,28,29,BLUE,r=2)+rect(175,162,34,58,r=2)+path('M17 230 L255 230',width=2)
    if name=='ship':
        return path('M15 164 L257 164 L229 216 L65 216 Z',width=5)+rect(48,87,53,69,BLUE,r=1)+rect(108,87,53,69,RED,r=1)+rect(168,87,53,69,ORANGE,r=1)+rect(90,23,48,58,r=1)+path('M114 23 L114 -2 L163 21 L114 21 M5 229 Q32 215 57 231 T111 229 T166 231 T221 229 T275 231',BLUE,4)
    if name=='document':
        return path('M65 10 L184 10 L229 55 L229 236 L65 236 Z')+path('M183 11 L183 56 L227 56 M91 91 L199 91 M91 115 L174 115 M91 140 L200 140 M91 164 L155 164',INK,3)+circle(181,200,24,BLUE)+check(177,198)
    if name=='stamp':
        return rect(41,173,195,40,fill='#E9D7BE',r=6)+path('M77 172 L77 148 Q77 132 101 130 L119 130 L119 95 Q94 48 128 26 Q162 10 178 45 Q185 65 162 95 L162 130 L181 130 Q206 134 206 150 L206 173',width=5)+path('M67 232 Q137 243 218 228',RED,7)+path('M45 249 L238 249',INK,2)
    if name=='phone':
        return rect(77,-2,140,250,r=20)+rect(88,16,117,201,BLUE,r=5,width=2)+path('M124 6 L167 6',width=3)+circle(146,232,5,width=2)+circle(146,81,24)+path('M105 149 Q106 111 146 111 Q187 111 187 149',width=4)+check(143,178)
    if name=='cloud':
        return path('M66 149 Q23 147 26 109 Q26 79 58 69 Q64 23 109 27 Q136 -2 169 20 Q198 20 205 61 Q254 58 258 104 Q262 146 220 149 Z',BLUE,4, '#E2E6DE')+path('M142 157 L142 228 M139 192 L76 192 L76 222 M145 192 L213 192 L213 222',width=3)+rect(46,223,61,26,r=5)+rect(112,228,61,26,r=5)+rect(183,223,61,26,r=5)
    if name=='shield':
        return path('M143 4 Q190 31 237 36 L226 145 Q213 207 143 246 Q74 207 61 145 L49 36 Q98 31 143 4 Z',width=5)+path('M143 24 Q182 45 216 51 L207 141 Q199 185 143 222 Q87 185 79 141 L70 51 Q104 45 143 24',BLUE,2)+check(136,129)
    if name=='wallet':
        return rect(25,71,236,155,r=15)+path('M34 69 L207 25 L226 69',width=4)+rect(167,122,106,63,BLUE,'#D8DFDC',r=9)+circle(193,153,7,BLUE)+path('M58 94 L111 94 M56 204 L130 204',INK,2)+circle(91,25,25,ORANGE)+path('M90 11 L90 38 M82 16 Q104 15 99 24 Q80 24 85 32 L101 31',ORANGE,2)
    if name=='building':
        return path('M28 70 L143 0 L260 70 Z',BLUE,5)+path('M48 84 L239 84 M47 221 L239 221 M28 240 L260 240',width=5)+path('M62 96 L62 209 M102 96 L102 209 M182 96 L182 209 M222 96 L222 209',width=10)+rect(125,135,35,86,r=2)+circle(144,48,10,RED)
    if name=='person':
        return circle(144,58,43)+path('M103 51 Q106 -1 151 10 Q179 10 187 47 M122 68 Q142 84 163 67',width=3)+path('M69 241 L76 160 Q79 125 114 119 L144 145 L175 120 Q211 128 215 160 L224 241',width=5)+path('M144 147 L144 224 M96 168 L99 238 M195 168 L192 238',width=3)+path('M116 120 L128 167 L145 146 L164 166 L175 120',BLUE,4)
    if name=='magnify':
        return circle(125,99,78)+circle(125,99,62,BLUE,width=2)+path('M182 157 L248 224 Q260 239 242 251 L174 181',width=7)+check(118,104)
    if name=='plate':
        return rect(17,62,255,143,r=16)+rect(29,74,231,119,BLUE,r=8,width=2)+circle(46,91,3)+circle(244,91,3)+path('M60 122 L104 122 M126 122 L175 122 M61 159 L109 159 M131 159 L223 159',width=7)
    if name=='calendar':
        return rect(37,35,219,200,r=12)+path('M37 90 L256 90 M88 16 L88 57 M207 16 L207 57',width=6)+path('M76 125 L105 125 M130 125 L158 125 M184 125 L213 125 M76 163 L105 163 M130 163 L158 163 M76 202 L105 202',INK,4)+circle(200,185,39,BLUE,fill=PAPER)+path('M200 159 L200 185 L217 195',BLUE,4)
    if name=='truck':
        return rect(17,62,153,135,r=6)+path('M170 103 L226 103 L270 146 L270 197 L170 197 M225 109 L225 148 L265 148',width=5)+circle(69,206,28,fill=PAPER)+circle(224,206,28,fill=PAPER)+circle(69,206,12,BLUE)+circle(224,206,12,BLUE)+check(85,127)+path('M7 240 L279 240',INK,2)
    raise ValueError(name)

def svg(body,w=1280,h=720,background=True):
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}">'+(f'<rect width="{w}" height="{h}" fill="{PAPER}"/>' if background else '')+body+'</svg>'

for i,s in enumerate(SCENES,1):
    body=''
    for j,name in enumerate(s['icons']):
        x=53+j*402
        body+=f'<g transform="translate({x+35},218) scale(1.02)">{icon(name)}</g>'
        body+=path(f'M{x+40} 506 Q{x+160} 514 {x+291} 505',BLUE if j==1 else ORANGE,3)
        if j<2: body+=path(f'M{x+339} 351 l24 0 m-10 -10 l10 10 l-10 10',INK,3)
    source=svg(body)
    (ART/f'scene-{i:02}.svg').write_text(source)
    cairosvg.svg2png(bytestring=source.encode(),write_to=str(ART/f'scene-{i:02}.png'))

# A newly drawn, unbranded hand and pencil; tip is the upper-left anchor.
hand=path('M5 6 L80 64 L94 48 L19 0 Z',INK,2,'#467DAB')+path('M57 48 Q72 37 86 47 L114 72 Q140 76 143 99 L165 135 L125 170 L90 147 Q70 137 69 118 L57 91 Q45 73 56 65 L75 82 L56 61 Q48 52 57 48 Z',INK,2,'#E9C9A6')+path('M82 78 L103 94 M68 93 L87 110 M77 120 L99 128',INK,1.8)+path('M125 170 L166 136 L191 164 L151 198 Z',INK,2,'#DCE3DE')
cairosvg.svg2png(bytestring=svg(hand,200,205,False).encode(),write_to=str(ART/'hand.png'))

font=ImageFont.truetype('/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf',20)
sheet=Image.new('RGB',(1280,4*230),PAPER)
for i,s in enumerate(SCENES,1):
    im=Image.open(ART/f'scene-{i:02}.png').convert('RGB').resize((420,236))
    im=im.crop((0,45,420,215))
    x=((i-1)%3)*426;y=((i-1)//3)*230
    sheet.paste(im,(x,y+40));ImageDraw.Draw(sheet).text((x+12,y+8),f'{i:02}. '+s['title'][:26],font=font,fill=INK)
sheet.save(ART/'contact-sheet.jpg')
print('12 scenes and original hand prepared')
